<?php 
$server = "localhost";
$user = "root";
$password = "";
$db = "loginregister";

$con = mysqli_connect($server, $user, $password, $db)

?>
