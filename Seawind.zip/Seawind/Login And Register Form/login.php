<?php  
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Login Page</title>
</head>

<body>

<?php  
include 'db.php';

if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $email_search = "select * from userregister where email = '$email'";
    $query = mysqli_query($con, $email_search);

    $email_count = mysqli_num_rows($query);

    if($email_count){
        $email_pass = mysqli_fetch_assoc($query);

        $db_pass = $email_pass['password'];

        $_SESSION['name'] = $email_pass['name'];
        $pass_decode = password_verify($password, $db_pass);

        if($pass_decode){

?>
<script>
window.location = "home.php";
    </script>
    <?php
        }else{
           echo"pasword incorrect"; 
        }
        }else{
            echo "invalid email";
        }
    }

?>
    <form action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>" method="POST">
        <div class="login">
            <h2>Login Page</h2>
            <div class="loginDetails">

                <div class="input userName">
                    <label for="">Email</label>
                    <input type="text" name="email" placeholder="Enter Your Email">
                </div>

                <div class="input userName">
                    <label for="">Password</label>
                    <input type="password" name="password" placeholder="Enter The Password">
                </div>
                <small>You don't have accounnt ? <a href="register.php">Register</a></small>
                <div class="loginBtn">
                    <button href="" type="submit" name="submit">Login In</button>
                </div>
            </div>
        </div>
    </form>
</body>

</html>
